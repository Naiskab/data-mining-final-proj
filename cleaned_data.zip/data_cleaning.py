# %% [markdown]
"""
Script for Cleaning and Preprocessing Train and Test Datasets

This Python script performs data cleaning and preprocessing on two original datasets: 'train.csv' and 'test.csv'.

### Purpose:
To prepare clean and reliable datasets by handling common data issues such as unnecessary columns, outliers, duplicate rows, and missing values.

### Cleaning Steps:
1. **Unnecessary Columns Removal**:
   - The 'Unnamed: 0' column is removed as it is an artifact from saving and reloading CSV files and does not contribute to the analysis.

2. **Outlier Detection and Removal**:
   - Numeric columns 'Departure Delay in Minutes' and 'Arrival Delay in Minutes' are checked for outliers using the Interquartile Range (IQR) method.
   - Outliers are defined as values outside the range [Q1 - 1.5*IQR, Q3 + 1.5*IQR] and are removed to retain meaningful data.

3. **Duplicate Rows Handling**:
   - Duplicate rows are identified and removed to maintain data integrity and avoid skewed results.

4. **Missing Values Handling**:
   - Missing values in 'Arrival Delay in Minutes' are imputed with the median value to preserve dataset consistency.

5. **Dataset-Specific Cleaning**:
   - Train and test datasets are cleaned independently to ensure both datasets are free from inconsistencies.

### Output:
- Cleaned training dataset saved back to 'train.csv'.
- Cleaned testing dataset saved back to 'test.csv'.


"""



# %%
import pandas as pd



# %% [markdown]

# Load the  datasets
train_file_path = 'train.csv'
test_file_path = 'test.csv'

train_df = pd.read_csv(train_file_path)
test_df = pd.read_csv(test_file_path)

# Function to identify outliers based on the IQR method
def identify_outliers(df, column):
    q1 = df[column].quantile(0.25)
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    return df[(df[column] < lower_bound) | (df[column] > upper_bound)]

# Cleaning Train Dataset
# -----------------------
# Remove unnecessary 'Unnamed: 0' column
if 'Unnamed: 0' in train_df.columns:
    train_df.drop(columns=['Unnamed: 0'], inplace=True)

# Handle outliers in train dataset
for column in ['Departure Delay in Minutes', 'Arrival Delay in Minutes']:
    if column in train_df.columns:
        outliers = identify_outliers(train_df, column)
        if not outliers.empty:
            train_df = train_df[~train_df.index.isin(outliers.index)]

# Impute missing values in 'Arrival Delay in Minutes'
if 'Arrival Delay in Minutes' in train_df.columns:
    train_df['Arrival Delay in Minutes'].fillna(train_df['Arrival Delay in Minutes'].median(), inplace=True)

# Remove duplicate rows
train_df.drop_duplicates(inplace=True)

# Save the cleaned training dataset back to the original file
train_df.to_csv(train_file_path, index=False)

# Cleaning Test Dataset
# ----------------------
# Remove unnecessary 'Unnamed: 0' column
if 'Unnamed: 0' in test_df.columns:
    test_df.drop(columns=['Unnamed: 0'], inplace=True)

# Handle outliers in test dataset
for column in ['Departure Delay in Minutes', 'Arrival Delay in Minutes']:
    if column in test_df.columns:
        outliers = identify_outliers(test_df, column)
        if not outliers.empty:
            test_df = test_df[~test_df.index.isin(outliers.index)]

# Impute missing values in 'Arrival Delay in Minutes'
if 'Arrival Delay in Minutes' in test_df.columns:
    test_df['Arrival Delay in Minutes'].fillna(test_df['Arrival Delay in Minutes'].median(), inplace=True)

# Remove duplicate rows
test_df.drop_duplicates(inplace=True)

# Save the cleaned testing dataset back to the original file
test_df.to_csv(test_file_path, index=False)

print("Data cleaning completed. Cleaned datasets saved back to 'train.csv' and 'test.csv'.")

# %%
